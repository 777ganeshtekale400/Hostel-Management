<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>

	<!--Sidenav-->
                <div class="list-group bg-info" style="height: 90vh">
                    <a href="index.php" class="list-group-item list-group-item-action
                    bg-info text-center text-white">Dashboard
                    </a>
                    <a href="admin.php" class="list-group-item list-group-item-action
                    bg-info text-center text-white">Administrators</a>
                    <a href="" class="list-group-item list-group-item-action
                    bg-info text-center text-white">Doctors</a>
                    <a href="" class="list-group-item list-group-item-action
                    bg-info text-center text-white">Patient</a>


                </div>

                <!--ends-->

</body>
</html>